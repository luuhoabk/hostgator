/* Update updates version length */
ALTER TABLE "#__updates" ALTER COLUMN "version" TYPE varchar(32);
